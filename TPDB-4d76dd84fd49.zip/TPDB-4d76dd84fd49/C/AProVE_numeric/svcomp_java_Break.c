int main() {
    int i = 0;
    int c = 0;
    while (1) {
        if (i > 10) break;
        i++;
        c++;
    }
    return c;
}
