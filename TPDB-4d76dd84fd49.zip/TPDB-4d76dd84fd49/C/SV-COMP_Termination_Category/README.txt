C programs for termination analysis, contributed by 
Matthias Heizmann, 
Jan Leike, 
Amir Ben-Amram, 
Thomas Ströder, and
Caterina Urban.

