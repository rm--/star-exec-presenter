/*
 * Date: 2012-03-19
 * Author: leike@informatik.uni-freiburg.de
 *
 * The loop is equivalent to false,
 * f(x) = 0 is a ranking function.
 */

int main()
{
	while (0) {
	}
	return 0;
}

