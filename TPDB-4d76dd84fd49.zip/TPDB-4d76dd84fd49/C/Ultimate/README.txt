C programs for termination analysis, that were used by
Ultimate Büchi Automizer 
http://ultimate.informatik.uni-freiburg.de/BuchiAutomizer/
and
Ultimate Lasso Ranker 
http://ultimate.informatik.uni-freiburg.de/LassoRanker/

The benchmarks were contributed by Jan Leike and Matthias Heizmann.
You may use and redistribute them according to the (2-clause) BSD license 
that is shipped with these examples.