/*
 * Date: 2013-12-16
 * Author: leike@informatik.uni-freiburg.de
 *
 * Very simple example for non-termination
 */

int main()
{
	while (1) {
		// do nothing
	}
	return 0;
}

