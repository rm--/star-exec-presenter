/*
 * Date: 2013-05-02
 * Author: heizmann@informatik.uni-freiburg.de
 *
 */

int main()
{
	int x = 7;
	while (1) {
		x = 2;
	}
	return 0;
}
