/*
 * Date: 2014-06-26
 * Author: leike@informatik.uni-freiburg.de
 */

extern int __VERIFIER_nondet_int();

int main()
{
	int x = __VERIFIER_nondet_int();
	while (x >= 0) {
		x += __VERIFIER_nondet_int();
	}
	return 0;
}

